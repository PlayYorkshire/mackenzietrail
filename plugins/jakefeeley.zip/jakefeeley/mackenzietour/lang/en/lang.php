<?php return [
    'plugin' => [
        'name' => 'MacKenzie Tour',
        'description' => ''
    ]
];